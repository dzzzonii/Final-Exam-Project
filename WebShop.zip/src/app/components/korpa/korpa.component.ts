import { Component, OnInit } from '@angular/core';
import { WebshopService } from 'src/app/services/webshop.service';


@Component({
  selector: 'app-korpa',
  templateUrl: './korpa.component.html',
  styleUrls: ['./korpa.component.less']
})
export class KorpaComponent implements OnInit {

  constructor(private service: WebshopService) { }

  ngOnInit(): void {
  }
  public goTo(path:string): void {

    this.service.navigateTo(path);
  }

}
