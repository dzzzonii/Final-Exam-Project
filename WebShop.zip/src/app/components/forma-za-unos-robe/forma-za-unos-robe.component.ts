import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-forma-za-unos-robe',
  templateUrl: './forma-za-unos-robe.component.html',
  styleUrls: ['./forma-za-unos-robe.component.less']
})
export class FormaZaUnosRobeComponent implements OnInit {

  forma = new FormGroup({
    naziv: new FormControl(),
    cena: new FormControl(),
    opis: new FormControl(),
    kolicina: new FormControl(),
    sifra: new FormControl(),
    mernajedinica: new FormControl()
  });

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log(this.forma);
  }
}
