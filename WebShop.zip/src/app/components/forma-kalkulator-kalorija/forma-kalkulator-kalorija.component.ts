import { Component, OnInit } from '@angular/core';
import { WebshopService } from 'src/app/services/webshop.service';

@Component({
  selector: 'app-forma-kalkulator-kalorija',
  templateUrl: './forma-kalkulator-kalorija.component.html',
  styleUrls: ['./forma-kalkulator-kalorija.component.less']
})
export class FormaKalkulatorKalorijaComponent implements OnInit {

  constructor(
    private service: WebshopService
  ) { }

  ngOnInit(): void {
  }

  public goTo(path:string): void{
    this.service.navigateTo(path);
  }

}
