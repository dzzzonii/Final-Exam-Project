import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormaKalkulatorKalorijaComponent } from './forma-kalkulator-kalorija.component';

describe('FormaKalkulatorKalorijaComponent', () => {
  let component: FormaKalkulatorKalorijaComponent;
  let fixture: ComponentFixture<FormaKalkulatorKalorijaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormaKalkulatorKalorijaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormaKalkulatorKalorijaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
