import { Component, OnInit } from '@angular/core';
import { WebshopService } from 'src/app/services/webshop.service';

@Component({
  selector: 'app-side-menu-bar',
  templateUrl: './side-menu-bar.component.html',
  styleUrls: ['./side-menu-bar.component.less']
})
export class SideMenuBarComponent implements OnInit {

  constructor(private service: WebshopService) { }

  ngOnInit(): void {
  }

  public goTo(path:string): void {

    this.service.navigateTo(path);
  }

}
