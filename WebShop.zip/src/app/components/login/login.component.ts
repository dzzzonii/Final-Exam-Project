import { Component, Injectable, OnInit } from '@angular/core';
import {  Input, ViewChild } from '@angular/core';
import { inject } from '@angular/core/testing';
import { WebshopService } from 'src/app/services/webshop.service';

@Component({
  
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})



@Injectable()
export class LoginComponent implements OnInit {
  
  username='';
  password='';
  constructor(private service: WebshopService) { }
      

   
    ngOnInit(): void {};

    submitHandler(myForm, path){
      console.log(myForm);
      alert("Uspesno ste se ulogovali!");
      this.service.navigateTo(path);
      
    }
   

    
  }


 
  


