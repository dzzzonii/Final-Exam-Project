import { Component, OnInit } from '@angular/core';
import { WebshopService } from 'src/app/services/webshop.service';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.less']
})
export class ProfilComponent implements OnInit {

  constructor(
    private service: WebshopService


  ) { }
  ngOnInit(): void {
  }

  public goTo(path:string): void {

    this.service.navigateTo(path);
  }
}
