import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { WebshopService } from './services/webshop.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less'],
  providers:[WebshopService]
})
export class AppComponent {

  constructor(

    private service: WebshopService
  ){}


   title = 'project20221';

   name: string ="Martin";
}
