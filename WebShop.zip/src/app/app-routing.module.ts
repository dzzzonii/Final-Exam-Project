import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { FormaZaUnosRobeComponent } from './components/forma-za-unos-robe/forma-za-unos-robe.component';
import { ProfilComponent } from './profil/profil.component';
import { FormaKalkulatorKalorijaComponent } from './components/forma-kalkulator-kalorija/forma-kalkulator-kalorija.component';
import { KorpaComponent } from './components/korpa/korpa.component';
import { WrapperComponent } from './components/wrapper/wrapper.component';

const routes: Routes = [{path: 'wrapper', component: WrapperComponent,
children: [
  {path: 'home', component: AppComponent},
  {path: 'unosrobe', component: FormaZaUnosRobeComponent},
  {path: 'profil', component: ProfilComponent},
  {path: 'korpa', component: KorpaComponent},
  {path: 'kalkulatorKalorija', component: FormaKalkulatorKalorijaComponent}
]}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }