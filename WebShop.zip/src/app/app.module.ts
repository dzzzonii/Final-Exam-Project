import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RouterModule } from '@angular/router';
import { FormaZaUnosRobeComponent } from './components/forma-za-unos-robe/forma-za-unos-robe.component';
import { SideMenuBarComponent } from './components/side-menu-bar/side-menu-bar.component';
import { WebshopService } from './services/webshop.service';
import { ProfilComponent } from './profil/profil.component';
import { KorpaComponent } from './components/korpa/korpa.component';

import { FormaKalkulatorKalorijaComponent } from './components/forma-kalkulator-kalorija/forma-kalkulator-kalorija.component';
import { WrapperComponent } from './components/wrapper/wrapper.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent ,
    FormaZaUnosRobeComponent,
    SideMenuBarComponent,
    ProfilComponent,
    KorpaComponent,
    FormaKalkulatorKalorijaComponent,
    WrapperComponent
    
  ],
  imports: [
    BrowserModule, 
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path:'', component: LoginComponent},
      {path: '', component: WrapperComponent,
    children: [
      {path: 'home', component: AppComponent},
      {path: 'unosrobe', component: FormaZaUnosRobeComponent},



      
      {path: 'korpa', component: KorpaComponent},
      {path: 'profil', component: ProfilComponent},
      {path: 'kalkulatorKalorija', component: FormaKalkulatorKalorijaComponent}
    ]}
    ])


  ],
  providers: [WebshopService],
  bootstrap: [AppComponent]
})
export class AppModule { }
