import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class WebshopService {
  
  constructor(private router: Router, private route: ActivatedRoute) { }


  navigateTo(path: string):void{
    this.router.navigate([path], {relativeTo:this.route});
  }



  
}
